function hide(){
    document.getElementById('logo').className = "hidden";
    document.getElementById('ben').className = "hidden";
    document.getElementById('juju').className = "hidden";
    document.getElementById('minkah').className = "hidden";
    document.getElementById('tj').className = "hidden";
  }